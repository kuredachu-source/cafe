# ELGA CAFE — Deploy to Vercel

## How to deploy in 3 steps

### Step 1 — Push to GitHub
1. Create a new repo on github.com (call it `elga-cafe`)
2. Upload all these files into the repo (drag & drop the whole folder)

### Step 2 — Connect to Vercel
1. Go to vercel.com and sign in
2. Click **"Add New Project"**
3. Import your `elga-cafe` GitHub repo
4. Vercel will auto-detect it as a **Vite** project
5. Click **Deploy** — done in ~1 minute

### Step 3 — Your live URLs
- Customer menu: `https://your-app.vercel.app`
- Staff terminal: `https://your-app.vercel.app` → click Staff Terminal
- Table QR links: `https://your-app.vercel.app?table=T1`

## How the QR works after deployment
1. Open Staff Terminal → QR Generator
2. Enter a table number (T1, T2, etc.) and click Generate
3. The QR encodes your real Vercel URL automatically
4. Print the QR and put it on the table
5. Customer scans with phone camera → goes straight to the customer menu for that table ✅

## Local development
```
npm install
npm run dev
```

## Build for production
```
npm run build
```
